/*
 	Name: Prateek Garg
	Roll No: MT2022081

	Q24.: Write a program to create an orphan process.

*/


#include <sys/types.h> 
#include <unistd.h>    
#include <stdio.h>     

void main()
{
    pid_t childPid;

    if ((childPid = fork()) != 0)
    {
        
        printf("Parent PID: %d\n", getpid());
        printf("Putting Parent to sleep for 10s\n");
        sleep(10); 
        printf("Exiting parent!\n");
        _exit(0);
    }
    else
    {
        
        printf("Child PID: %d\n", getpid());
        printf("Putting child to sleep for 12s!\n");
        sleep(12);
        printf("Child is now awake!\n");
	_exit(0);
    }
}

