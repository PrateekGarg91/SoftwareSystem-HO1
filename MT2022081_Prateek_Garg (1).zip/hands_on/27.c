/*
 	Name: Prateek Garg
	Roll No: MT2022081

	Q27.: 

*/


